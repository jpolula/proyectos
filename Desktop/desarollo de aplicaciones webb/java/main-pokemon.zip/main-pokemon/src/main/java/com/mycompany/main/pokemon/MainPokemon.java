/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main.pokemon;

/**
 *
 * @author Juan Pedro
 */
public class MainPokemon
{

    public static void main(String[] args) 
    {
        Pichu pichu=new Pichu("Ash");
        
        pichu.mostrar();
        
        System.out.println("--------------------------------------------");
        
        int danio=0; //Variable que usaremos para guardar el daño
        
        while(pichu.getExp()<=49)
        {
            int dañoMovimiento=pichu.ataqueRapido(); //variable que usaremos para saber el daño que haremos con el movimiento de Pichu.
            danio+=dañoMovimiento;
            if(danio>=100) //Si el daño es mayor a 100 sumaremos 15 de experiencia al objeto creado.
            {
                pichu.cambiarExperiencia();
                danio-=100; //Le restamos 100 ya que al conseguir experiencia se reinicia el daño y dejamos el resto de lo que haya quedado.
                if(pichu.getExp()>=50)
                {
                    pichu=new Pikachu(pichu.getExp()); //En el argumento le paso la experiencia que tengo hasta ahora.
                }
            } 
        }
        
        System.out.println("-----------------------------------------------------");
        
        pichu.mostrar(); //Muestro a Pichu evolucionado
        
         while(pichu.getExp()<75)
        {
            int dañoMovimiento=pichu.ataqueRapido(); //variable que usaremos para saber el daño que haremos con el movimiento de Pichu.
            danio+=dañoMovimiento;
            if(danio>=100) //Si el daño es mayor a 100 sumaremos 15 de experiencia al objeto creado.
            {
                pichu.cambiarExperiencia();
                danio-=100; //Le restamos 100 ya que al conseguir experiencia se reinicia el daño y dejamos el resto de lo que haya quedado.
                if(pichu.getExp()>=75)
                {
                    pichu=new Raichu(pichu.getExp());
                }
            } 
        }
         System.out.println("---------------------------------------------------------------------------");
         pichu.mostrar(); //Muestro a Pikachu evolucionado.
        
         //Haremos un ejemplo de combate entre 2 pokemon.
         
         Pichu raichu=new Raichu();
         
         Pichu pikachu=new Pikachu();
         while(raichu.getSalud()>0||pikachu.getSalud()>0)
         {
             int daño;
             daño=raichu.ataqueRapido(); //raichu hace un ataque
             pikachu.restarSalud(daño); //pikachu recibe el golpe y le baja la defensa
             
             daño=pikachu.ataqueRapido();//Turno de Pikachu.
             raichu.restarSalud(daño); //Le restamos la vida a Raichu.
         }
         
         if(pikachu.getSalud()>=0) //Si Pikachu no tiene vida ya sabemos que ha ganado Raichu. 
         {
             System.out.println("Gano Raichu");
         }
         else //Si Raichu no tiene vida a ganado Pikachu
         {
             System.out.println("Gano Pikachuuuuu");
         }
    }
}
