module com.mycompany.varioscontroles {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.varioscontroles to javafx.fxml;
    exports com.mycompany.varioscontroles;

}
