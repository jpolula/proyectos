package com.mycompany.varioscontroles;

import java.io.IOException;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;

public class PrimaryController {

    @FXML
    private Slider slider1;
    @FXML
    private Slider slider2;
    @FXML
    private ImageView imagen;
    @FXML
    private Label labelSlider;
    @FXML
    private ColorPicker colores;
    @FXML
    private Button primaryButton;
    
    @FXML
    private void cargarImagen() throws IOException 
    {
        //App.setRoot("secondary");
        
        //imagen.setImage(new Image("file:///C:/Users/Cifu/Documents/NetBeansProjects/mavenproject1/src/main/java/com/mycompany/mavenproject1/ACE2.jpg"));
        imagen.setImage(new Image("file:ACE2.jpg"));
    }
    
    @FXML
    private void updateLabel()
    {
        
        int valor1 = (int) slider1.getValue();
        int valor2 = (int) slider2.getValue();
        
        labelSlider.setText(String.valueOf(valor1) + ", " + String.valueOf(valor2));
                 
        escalarImagen();
    }
    
    
    private void escalarImagen()
    {
        double escalaX =  slider1.getValue() / 100;
        double escalaY =  slider2.getValue() / 100;
       
        imagen.setScaleX(escalaX);
        imagen.setScaleY(escalaY);
    }
    
    @FXML
    private void cambiarColorBoton()
    {
        Color c = colores.getValue();
        
        int green = (int) (c.getGreen()*255);
        String greenString = Integer.toHexString(green);
        if(greenString.length()==1)
            greenString = "0" + greenString;

        int red = (int) (c.getRed()*255);
        String redString = Integer.toHexString(red);
         if(redString.length()==1)
            redString = "0" + redString;

        int blue = (int) (c.getBlue()*255);
        String blueString = Integer.toHexString(blue);
         if(blueString.length()==1)
            blueString = "0" + blueString;

        String hexColor = "#"+redString+greenString+blueString;
        
        
        String cadenaCSS = "-fx-background-color: " + hexColor + "; ";
        
        primaryButton.setStyle(cadenaCSS);
    }
    
    @FXML
    private void alerta()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Elige");
        alert.setHeaderText("Haz tu elección");
        alert.setContentText("¡Debes elegir una opción!");
        
        Optional<ButtonType> result = alert.showAndWait();
        
        if(result.get() == ButtonType.OK)
        {
            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
            alert2.setTitle("Información");
            alert2.setHeaderText("Un cuadro de información");
            alert2.setContentText("¡Has pulsado que SÍ!");
            alert2.showAndWait();
        }
        else
        {
            Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
            alert2.setTitle("Información");
            alert2.setHeaderText("Un cuadro de información");
            alert2.setContentText("¡Has pulsado que NO!");
            alert2.showAndWait();
        }
        
        
        
        
    }
}
